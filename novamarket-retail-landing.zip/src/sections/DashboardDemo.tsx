import { useState, useMemo } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, AreaChart, Area, LineChart, Line, Legend,
} from 'recharts';
import dashboardData from '@/data/dashboardData.json';

/* ------------------------------------------------------------------ */
/*  TYPES                                                              */
/* ------------------------------------------------------------------ */
type TabKey = 'resumen' | 'productos' | 'geo' | 'satisfaccion';

/* ------------------------------------------------------------------ */
/*  CONSTANTS                                                          */
/* ------------------------------------------------------------------ */
const COLORS = {
  teal: '#0D9488',
  tealGlow: '#14B8A6',
  tealDark: '#0A6B63',
  amber: '#F59E0B',
  amberSoft: '#FBBF24',
  rose: '#F43F5E',
  ivory: '#F5F5F0',
  ash: '#6B7280',
  fog: '#374151',
  slate: '#1A1A20',
  ink: '#111114',
  obsidian: '#0A0A0C',
};

const PIE_COLORS = [COLORS.teal, COLORS.amber, COLORS.rose, COLORS.fog, COLORS.ash];

const TABS: { key: TabKey; label: string; num: string }[] = [
  { key: 'resumen', label: 'Resumen Ejecutivo', num: '01' },
  { key: 'productos', label: 'Productos y Categorías', num: '02' },
  { key: 'geo', label: 'Países y Canales', num: '03' },
  { key: 'satisfaccion', label: 'Satisfacción y Logística', num: '04' },
];

const PAISES = ['Todos', ...dashboardData.country.map(c => c.pais)];
const CATEGORIAS = ['Todos', ...dashboardData.category.map(c => c.categoria)];
const CANALES = ['Todos', ...dashboardData.channel.map(c => c.canal)];

/* ------------------------------------------------------------------ */
/*  FORMATTERS                                                         */
/* ------------------------------------------------------------------ */
const fmtEuro = (v: number) =>
  '€' + v.toLocaleString('es-ES', { maximumFractionDigits: 0 });

const fmtK = (v: number) => {
  if (v >= 1000) return '€' + (v / 1000).toFixed(0) + 'K';
  return '€' + v.toFixed(0);
};

/* ------------------------------------------------------------------ */
/*  KPI CARD                                                           */
/* ------------------------------------------------------------------ */
function KPICard({ label, value, color = COLORS.teal }: { label: string; value: string; color?: string }) {
  return (
    <div className="card-interactive p-5 cursor-default">
      <p className="font-label text-ash text-xs mb-2">{label}</p>
      <p className="font-mono font-bold text-xl" style={{ color }}>{value}</p>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  FILTER BADGE                                                       */
/* ------------------------------------------------------------------ */
function FilterSelect({
  label, options, value, onChange,
}: {
  label: string; options: string[]; value: string; onChange: (v: string) => void;
}) {
  return (
    <div className="flex items-center gap-2">
      <span className="font-label text-ash text-xs">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="filter-select"
      >
        {options.map(o => <option key={o} value={o} style={{ backgroundColor: COLORS.slate }}>{o}</option>)}
      </select>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  CUSTOM TOOLTIP                                                     */
/* ------------------------------------------------------------------ */
function CustomTooltip({ active, payload, label, valueFormatter = (v: number) => String(v) }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg px-4 py-3 text-sm shadow-xl" style={{ backgroundColor: COLORS.ink, border: `1px solid ${COLORS.fog}` }}>
      {label && <p className="text-ash mb-1 font-medium">{label}</p>}
      {payload.map((p: any, i: number) => (
        <p key={i} className="font-mono text-xs" style={{ color: p.color || COLORS.ivory }}>
          {p.name}: {valueFormatter(p.value)}
        </p>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  MAIN DASHBOARD COMPONENT                                           */
/* ------------------------------------------------------------------ */
export default function DashboardDemo() {
  const [activeTab, setActiveTab] = useState<TabKey>('resumen');
  const [filterPais, setFilterPais] = useState('Todos');
  const [filterCat, setFilterCat] = useState('Todos');
  const [filterCanal, setFilterCanal] = useState('Todos');

  /* ---- Filtered data ---- */
  const fCountry = useMemo(() =>
    filterPais === 'Todos' ? dashboardData.country : dashboardData.country.filter(c => c.pais === filterPais),
    [filterPais]);

  const fChannel = useMemo(() =>
    filterCanal === 'Todos' ? dashboardData.channel : dashboardData.channel.filter(c => c.canal === filterCanal),
    [filterCanal]);

  const fProducts = useMemo(() => {
    let p = [...dashboardData.products];
    if (filterCat !== 'Todos') p = p.filter(pr => pr.categoria === filterCat);
    if (filterPais !== 'Todos') {
      // approximate: scale by country's share
      const c = dashboardData.country.find(x => x.pais === filterPais);
      const ratio = c ? c.ingresos / dashboardData.total_revenue : 1;
      p = p.map(pr => ({ ...pr, ingresos: pr.ingresos * ratio }));
    }
    return p.sort((a, b) => b.ingresos - a.ingresos).slice(0, 8);
  }, [filterCat, filterPais]);

  const fMonthly = useMemo(() => {
    // scale monthly by filter ratios
    let revenueRatio = 1;
    if (filterPais !== 'Todos') {
      const c = dashboardData.country.find(x => x.pais === filterPais);
      revenueRatio = c ? c.ingresos / dashboardData.total_revenue : 1;
    }
    if (filterCanal !== 'Todos') {
      const ch = dashboardData.channel.find(x => x.canal === filterCanal);
      revenueRatio *= ch ? ch.ingresos / dashboardData.total_revenue : 1;
    }
    return dashboardData.monthly.map(m => ({
      ...m,
      ingresos: Math.round(m.ingresos * revenueRatio),
    }));
  }, [filterPais, filterCanal]);

  /* ---- Computed KPIs ---- */
  const totalRevenue = fCountry.reduce((s, c) => s + c.ingresos, 0);
  const totalOrders = fCountry.reduce((s, c) => s + c.pedidos, 0);
  const totalCustomers = fCountry.reduce((s, c) => s + c.clientes, 0);
  const avgSat = fCountry.length
    ? fCountry.reduce((s, c) => s + c.satisfaccion, 0) / fCountry.length
    : 0;

  return (
    <section id="dashboard" className="w-full bg-obsidian">
      <div className="page-gutter section-gap content-max">
        {/* Header */}
        <div className="mb-10">
          <p className="font-label text-teal mb-3">// DASHBOARD INTERACTIVO</p>
          <h2 className="font-display font-display-l text-ivory">Demo de visualizaciones</h2>
          <p className="mt-3 text-ash max-w-[600px] text-sm leading-relaxed">
            Explora los datos de NovaMarket Retail con filtros interactivos. Selecciona país, categoría o canal para segmentar la información. Este es un adelanto de lo que encontrarás en el dashboard completo de Power BI.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
          {TABS.map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`tab-btn ${activeTab === tab.key ? 'active' : ''}`}
            >
              <span className="font-mono text-xs opacity-60">{tab.num}</span>
              {tab.label}
            </button>
          ))}
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-4 mb-8 pb-6" style={{ borderBottom: `1px solid ${COLORS.fog}` }}>
          <FilterSelect label="País" options={PAISES} value={filterPais} onChange={setFilterPais} />
          <FilterSelect label="Categoría" options={CATEGORIAS} value={filterCat} onChange={setFilterCat} />
          <FilterSelect label="Canal" options={CANALES} value={filterCanal} onChange={setFilterCanal} />
          <button
            onClick={() => { setFilterPais('Todos'); setFilterCat('Todos'); setFilterCanal('Todos'); }}
            className="text-xs font-label text-teal transition-all duration-200 hover:text-teal-glow underline underline-offset-2 hover:no-underline"
          >
            LIMPIAR FILTROS
          </button>
        </div>

        {/* ===================== TAB 01: RESUMEN EJECUTIVO ===================== */}
        {activeTab === 'resumen' && (
          <div className="animate-in fade-in duration-500">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <KPICard label="Ingresos totales" value={fmtEuro(totalRevenue)} />
              <KPICard label="Pedidos" value={totalOrders.toLocaleString('es-ES')} color={COLORS.amber} />
              <KPICard label="Clientes" value={totalCustomers.toLocaleString('es-ES')} color={COLORS.tealGlow} />
              <KPICard label="Satisfacción media" value={`${avgSat.toFixed(2)}/5`} color={COLORS.rose} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Monthly revenue area chart */}
              <div className="card-interactive p-6">
                <h3 className="font-heading text-ivory text-base mb-1">Evolución mensual de ingresos</h3>
                <p className="text-ash text-xs mb-6">Tendencia de ingresos brutos a lo largo de 2025</p>
                <ResponsiveContainer width="100%" height={280}>
                  <AreaChart data={fMonthly} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="revGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor={COLORS.teal} stopOpacity={0.4} />
                        <stop offset="100%" stopColor={COLORS.teal} stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke={COLORS.fog} opacity={0.3} />
                    <XAxis dataKey="mes" stroke={COLORS.ash} fontSize={11} tickLine={false} axisLine={false} />
                    <YAxis stroke={COLORS.ash} fontSize={11} tickLine={false} axisLine={false} tickFormatter={fmtK} width={50} />
                    <Tooltip content={<CustomTooltip valueFormatter={fmtEuro} />} />
                    <Area type="monotone" dataKey="ingresos" name="Ingresos" stroke={COLORS.teal} strokeWidth={2.5} fill="url(#revGrad)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>

              {/* Monthly orders bar chart */}
              <div className="card-interactive p-6">
                <h3 className="font-heading text-ivory text-base mb-1">Volumen de pedidos por mes</h3>
                <p className="text-ash text-xs mb-6">Cantidad de pedidos procesados mensualmente</p>
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={fMonthly} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={COLORS.fog} opacity={0.3} />
                    <XAxis dataKey="mes" stroke={COLORS.ash} fontSize={11} tickLine={false} axisLine={false} />
                    <YAxis stroke={COLORS.ash} fontSize={11} tickLine={false} axisLine={false} width={40} />
                    <Tooltip content={<CustomTooltip />} />
                    <Bar dataKey="pedidos" name="Pedidos" fill={COLORS.amber} radius={[4, 4, 0, 0]} barSize={24} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Satisfaction trend */}
              <div className="card-interactive p-6">
                <h3 className="font-heading text-ivory text-base mb-1">Tendencia de satisfacción</h3>
                <p className="text-ash text-xs mb-6">Puntuación media de satisfacción por mes (1-5)</p>
                <ResponsiveContainer width="100%" height={280}>
                  <LineChart data={fMonthly} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={COLORS.fog} opacity={0.3} />
                    <XAxis dataKey="mes" stroke={COLORS.ash} fontSize={11} tickLine={false} axisLine={false} />
                    <YAxis domain={[3, 5]} stroke={COLORS.ash} fontSize={11} tickLine={false} axisLine={false} width={30} />
                    <Tooltip content={<CustomTooltip valueFormatter={(v: number) => v.toFixed(2)} />} />
                    <Line type="monotone" dataKey="satisfaccion" name="Satisfacción" stroke={COLORS.rose} strokeWidth={2.5} dot={{ r: 4, fill: COLORS.rose }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Country mini pie */}
              <div className="card-interactive p-6">
                <h3 className="font-heading text-ivory text-base mb-1">Distribución por país</h3>
                <p className="text-ash text-xs mb-6">Ingresos por mercado ({filterPais !== 'Todos' ? filterPais : 'todos los mercados'})</p>
                <ResponsiveContainer width="100%" height={280}>
                  <PieChart>
                    <Pie
                      data={fCountry}
                      dataKey="ingresos"
                      nameKey="pais"
                      cx="50%"
                      cy="50%"
                      outerRadius={90}
                      innerRadius={50}
                      stroke={COLORS.slate}
                      strokeWidth={2}
                    >
                      {fCountry.map((_, i) => (
                        <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip valueFormatter={fmtEuro} />} />
                    <Legend
                      verticalAlign="bottom"
                      iconType="circle"
                      iconSize={8}
                      formatter={(v: string) => <span className="text-ash text-xs">{v}</span>}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        )}

        {/* ===================== TAB 02: PRODUCTOS Y CATEGORÍAS ===================== */}
        {activeTab === 'productos' && (
          <div className="animate-in fade-in duration-500">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              {/* Category comparison */}
              <div className="card-interactive p-6">
                <h3 className="font-heading text-ivory text-base mb-1">Tecnología vs. Estilo de Vida</h3>
                <p className="text-ash text-xs mb-6">Comparativa de ingresos por categoría</p>
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart
                    data={dashboardData.category}
                    layout="vertical"
                    margin={{ top: 10, right: 30, left: 20, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke={COLORS.fog} opacity={0.3} horizontal={false} />
                    <XAxis type="number" stroke={COLORS.ash} fontSize={11} tickLine={false} axisLine={false} tickFormatter={fmtK} />
                    <YAxis dataKey="categoria" type="category" stroke={COLORS.ivory} fontSize={12} tickLine={false} axisLine={false} width={90} />
                    <Tooltip content={<CustomTooltip valueFormatter={fmtEuro} />} />
                    <Bar dataKey="ingresos" name="Ingresos" radius={[0, 6, 6, 0]} barSize={32}>
                      {dashboardData.category.map((_, i) => (
                        <Cell key={i} fill={i === 0 ? COLORS.amber : COLORS.teal} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Category satisfaction */}
              <div className="card-interactive p-6">
                <h3 className="font-heading text-ivory text-base mb-1">Satisfacción por categoría</h3>
                <p className="text-ash text-xs mb-6">Puntuación media de satisfacción (1-5)</p>
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={dashboardData.category} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={COLORS.fog} opacity={0.3} />
                    <XAxis dataKey="categoria" stroke={COLORS.ivory} fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis domain={[3.5, 4.2]} stroke={COLORS.ash} fontSize={11} tickLine={false} axisLine={false} width={30} />
                    <Tooltip content={<CustomTooltip valueFormatter={(v: number) => v.toFixed(2)} />} />
                    <Bar dataKey="satisfaccion" name="Satisfacción" radius={[6, 6, 0, 0]} barSize={60}>
                      {dashboardData.category.map((_, i) => (
                        <Cell key={i} fill={i === 0 ? COLORS.amber : COLORS.teal} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Top products bar */}
            <div className="card-interactive p-6">
              <h3 className="font-heading text-ivory text-base mb-1">Top productos por ingresos</h3>
              <p className="text-ash text-xs mb-6">{filterCat !== 'Todos' ? `Filtrado por: ${filterCat}` : 'Todos los productos'} {filterPais !== 'Todos' ? `· ${filterPais}` : ''}</p>
              <ResponsiveContainer width="100%" height={360}>
                <BarChart
                  data={fProducts}
                  layout="vertical"
                  margin={{ top: 10, right: 30, left: 10, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke={COLORS.fog} opacity={0.3} horizontal={false} />
                  <XAxis type="number" stroke={COLORS.ash} fontSize={11} tickLine={false} axisLine={false} tickFormatter={fmtK} />
                  <YAxis
                    dataKey="producto"
                    type="category"
                    stroke={COLORS.ivory}
                    fontSize={11}
                    tickLine={false}
                    axisLine={false}
                    width={160}
                    tickFormatter={(v: string) => v.length > 22 ? v.slice(0, 22) + '…' : v}
                  />
                  <Tooltip content={<CustomTooltip valueFormatter={fmtEuro} />} />
                  <Bar dataKey="ingresos" name="Ingresos" radius={[0, 6, 6, 0]} barSize={18}>
                    {fProducts.map((p, i) => (
                      <Cell key={i} fill={p.categoria === 'Tecnología' ? COLORS.teal : COLORS.amber} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
              <div className="flex gap-6 mt-4 justify-center">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-sm" style={{ backgroundColor: COLORS.teal }} />
                  <span className="text-xs text-ash">Tecnología</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-sm" style={{ backgroundColor: COLORS.amber }} />
                  <span className="text-xs text-ash">Estilo de Vida</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ===================== TAB 03: PAÍSES Y CANALES ===================== */}
        {activeTab === 'geo' && (
          <div className="animate-in fade-in duration-500">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              {/* Country revenue bars */}
              <div className="card-interactive p-6">
                <h3 className="font-heading text-ivory text-base mb-1">Ingresos por país</h3>
                <p className="text-ash text-xs mb-6">Desempeño de cada mercado</p>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={fCountry.sort((a, b) => b.ingresos - a.ingresos)}
                    layout="vertical"
                    margin={{ top: 10, right: 30, left: 20, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke={COLORS.fog} opacity={0.3} horizontal={false} />
                    <XAxis type="number" stroke={COLORS.ash} fontSize={11} tickLine={false} axisLine={false} tickFormatter={fmtK} />
                    <YAxis dataKey="pais" type="category" stroke={COLORS.ivory} fontSize={12} tickLine={false} axisLine={false} width={70} />
                    <Tooltip content={<CustomTooltip valueFormatter={fmtEuro} />} />
                    <Bar dataKey="ingresos" name="Ingresos" fill={COLORS.teal} radius={[0, 6, 6, 0]} barSize={28} />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Channel pie */}
              <div className="card-interactive p-6">
                <h3 className="font-heading text-ivory text-base mb-1">Mix por canal de venta</h3>
                <p className="text-ash text-xs mb-6">Distribución de ingresos por canal</p>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={fChannel}
                      dataKey="ingresos"
                      nameKey="canal"
                      cx="50%"
                      cy="50%"
                      outerRadius={95}
                      innerRadius={55}
                      stroke={COLORS.slate}
                      strokeWidth={2}
                      label={({ name, percent }: any) => `${name}: ${(percent * 100).toFixed(1)}%`}
                    >
                      {fChannel.map((_, i) => (
                        <Cell key={i} fill={[COLORS.teal, COLORS.amber, COLORS.fog][i % 3]} />
                      ))}
                    </Pie>
                    <Tooltip content={<CustomTooltip valueFormatter={fmtEuro} />} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Country detail table */}
            <div className="rounded-xl p-6 overflow-x-auto" style={{ backgroundColor: COLORS.slate, border: `1px solid ${COLORS.fog}` }}>
              <h3 className="font-heading text-ivory text-base mb-1">Detalle por mercado</h3>
              <p className="text-ash text-xs mb-6">Métricas completas por país</p>
              <table className="w-full text-left text-sm">
                <thead>
                  <tr style={{ borderBottom: `2px solid ${COLORS.fog}` }}>
                    <th className="font-label text-ash py-3 pr-4">País</th>
                    <th className="font-label text-ash py-3 pr-4 text-right">Ingresos</th>
                    <th className="font-label text-ash py-3 pr-4 text-right">Pedidos</th>
                    <th className="font-label text-ash py-3 pr-4 text-right">Clientes</th>
                    <th className="font-label text-ash py-3 pr-4 text-right">Unidades</th>
                    <th className="font-label text-ash py-3 text-right">Sat.</th>
                  </tr>
                </thead>
                <tbody>
                  {fCountry.sort((a, b) => b.ingresos - a.ingresos).map((c, i) => (
                    <tr key={i} className="hover:bg-obsidian/30 transition-colors" style={{ borderBottom: `1px solid rgba(55,65,81,0.3)` }}>
                      <td className="py-3 pr-4 text-ivory font-medium">{c.pais}</td>
                      <td className="py-3 pr-4 text-right font-mono text-teal">{fmtEuro(c.ingresos)}</td>
                      <td className="py-3 pr-4 text-right text-ash">{c.pedidos}</td>
                      <td className="py-3 pr-4 text-right text-ash">{c.clientes}</td>
                      <td className="py-3 pr-4 text-right text-ash">{c.unidades}</td>
                      <td className="py-3 text-right font-mono" style={{ color: c.satisfaccion >= 3.9 ? COLORS.teal : COLORS.amber }}>
                        {c.satisfaccion.toFixed(2)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ===================== TAB 04: SATISFACCIÓN Y LOGÍSTICA ===================== */}
        {activeTab === 'satisfaccion' && (
          <div className="animate-in fade-in duration-500">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              {/* Satisfaction distribution */}
              <div className="card-interactive p-6">
                <h3 className="font-heading text-ivory text-base mb-1">Distribución de satisfacción</h3>
                <p className="text-ash text-xs mb-6">Niveles de satisfacción del cliente</p>
                <ResponsiveContainer width="100%" height={280}>
                  <PieChart>
                    <Pie
                      data={dashboardData.satisfaction}
                      dataKey="count"
                      nameKey="nivel"
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      stroke={COLORS.slate}
                      strokeWidth={2}
                      label={({ name, percent }: any) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      <Cell fill={COLORS.teal} />
                      <Cell fill={COLORS.amber} />
                      <Cell fill={COLORS.rose} />
                    </Pie>
                    <Tooltip content={<CustomTooltip valueFormatter={(v: number) => v.toLocaleString('es-ES')} />} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="flex gap-6 mt-4 justify-center">
                  <div className="flex items-center gap-2"><span className="w-3 h-3 rounded-sm" style={{ backgroundColor: COLORS.teal }} /><span className="text-xs text-ash">Alta (4-5)</span></div>
                  <div className="flex items-center gap-2"><span className="w-3 h-3 rounded-sm" style={{ backgroundColor: COLORS.amber }} /><span className="text-xs text-ash">Media (3)</span></div>
                  <div className="flex items-center gap-2"><span className="w-3 h-3 rounded-sm" style={{ backgroundColor: COLORS.rose }} /><span className="text-xs text-ash">Baja (1-2)</span></div>
                </div>
              </div>

              {/* Satisfaction by country */}
              <div className="card-interactive p-6">
                <h3 className="font-heading text-ivory text-base mb-1">Satisfacción por país</h3>
                <p className="text-ash text-xs mb-6">Comparativa de puntuación media</p>
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={dashboardData.satisfactionByCountry} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={COLORS.fog} opacity={0.3} />
                    <XAxis dataKey="pais" stroke={COLORS.ivory} fontSize={11} tickLine={false} axisLine={false} />
                    <YAxis domain={[3.5, 4.3]} stroke={COLORS.ash} fontSize={11} tickLine={false} axisLine={false} width={30} />
                    <Tooltip content={<CustomTooltip valueFormatter={(v: number) => v.toFixed(2)} />} />
                    <Bar dataKey="satisfaccion" name="Satisfacción" radius={[6, 6, 0, 0]} barSize={32} fill={COLORS.tealGlow} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Satisfaction by channel */}
              <div className="card-interactive p-6">
                <h3 className="font-heading text-ivory text-base mb-1">Satisfacción por canal</h3>
                <p className="text-ash text-xs mb-6">Comparativa entre canales de venta</p>
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart data={dashboardData.satisfactionByChannel} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={COLORS.fog} opacity={0.3} />
                    <XAxis dataKey="canal" stroke={COLORS.ivory} fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis domain={[3.5, 4.3]} stroke={COLORS.ash} fontSize={11} tickLine={false} axisLine={false} width={30} />
                    <Tooltip content={<CustomTooltip valueFormatter={(v: number) => v.toFixed(2)} />} />
                    <Bar dataKey="satisfaccion" name="Satisfacción" radius={[6, 6, 0, 0]} barSize={45}>
                      {dashboardData.satisfactionByChannel.map((_, i) => (
                        <Cell key={i} fill={[COLORS.teal, COLORS.amber, COLORS.tealGlow][i]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Logistics KPIs */}
              <div className="rounded-xl p-6 flex flex-col justify-center" style={{ backgroundColor: COLORS.slate, border: `1px solid ${COLORS.fog}` }}>
                <h3 className="font-heading text-ivory text-base mb-1">Métricas logísticas</h3>
                <p className="text-ash text-xs mb-6">Indicadores operativos globales</p>
                <div className="space-y-4">
                  <div className="flex justify-between items-center py-3" style={{ borderBottom: `1px solid ${COLORS.fog}` }}>
                    <span className="text-ash text-sm">Costo total de envío</span>
                    <span className="font-mono font-bold text-rose">{fmtEuro(dashboardData.costs.costo_envio_total)}</span>
                  </div>
                  <div className="flex justify-between items-center py-3" style={{ borderBottom: `1px solid ${COLORS.fog}` }}>
                    <span className="text-ash text-sm">Ingreso neto logístico</span>
                    <span className="font-mono font-bold text-teal">{fmtEuro(dashboardData.costs.ingreso_neto_total)}</span>
                  </div>
                  <div className="flex justify-between items-center py-3" style={{ borderBottom: `1px solid ${COLORS.fog}` }}>
                    <span className="text-ash text-sm">Coste envío relativo</span>
                    <span className="font-mono font-bold text-amber">{dashboardData.costs.coste_envio_relativo_medio}%</span>
                  </div>
                  <div className="flex justify-between items-center py-3">
                    <span className="text-ash text-sm">Pedidos con satisfacción alta</span>
                    <span className="font-mono font-bold text-teal">69.3%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
